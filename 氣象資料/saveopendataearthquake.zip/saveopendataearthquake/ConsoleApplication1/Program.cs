﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Xml;
using System.Configuration;
using System.Data.SqlClient;
using System.Globalization;
using System.Threading;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;

namespace ConsoleApplication1
{
    class Program
    {
        static DateTime date = DateTime.Now;
        static ConnectionStringSettings settings = ConfigurationManager.ConnectionStrings["DBConnection"];
        static string LogPath = $@"{ConfigurationManager.AppSettings["LogPath"]}{ date.ToString("yyyy-MM-dd")}\";
        static string ApiUrl = ConfigurationManager.AppSettings["ApiUrl"];
        static List<ToSqlData> listData = new List<ToSqlData>();

        /// <summary>
        /// 對應sql欄位
        /// </summary>
        public class ToSqlData
        {
            public string earthquakeNo { get; set; }
            public string web { get; set; }
            public string reportImageURI { get; set; }
            public string originTime { get; set; }
            public string location { get; set; }
            public string magnitudeValue { get; set; }
            public string GIS_DATETIME { get; set; }

        }


        static void insertNewData()
        {

            string sqlcmd = "";
            foreach (var item in listData)
            {
                sqlcmd += $@"
if exists　(select earthquakeNo from [TransforData].[dbo].[earthquake_cwb]  where earthquakeNo = '{item.earthquakeNo}')
begin
    UPDATE [TransforData].[dbo].[earthquake_cwb] 
       SET [web] = '{item.web}'
          ,[reportImageURI] = '{item.reportImageURI}'
          ,[originTime] = '{item.originTime}'
          ,[location] = '{item.location}'
          ,[magnitudeValue] = '{item.magnitudeValue}'
          ,[GIS_DATETIME] = '{item.GIS_DATETIME}'
     WHERE earthquakeNo = '{item.earthquakeNo}'
end
else
begin
    INSERT INTO [TransforData].[dbo].[earthquake_cwb] 
               ([earthquakeNo]
               ,[web]
               ,[reportImageURI]
               ,[originTime]
               ,[location]
               ,[magnitudeValue]
               ,[GIS_DATETIME])
         VALUES
               ('{item.earthquakeNo}'
               ,'{item.web}'
               ,'{item.reportImageURI}'
               ,'{item.originTime}'
               ,'{item.location}'
               ,'{item.magnitudeValue}'
               ,'{item.GIS_DATETIME}')
end
" + "\r\n\r\n";

            }

            try
            {
                using (SqlConnection conn = new SqlConnection(settings.ConnectionString))
                {
                    conn.Open();

                    using (SqlCommand cmd = new SqlCommand(sqlcmd, conn))
                    {
                        Console.WriteLine(sqlcmd);
                        File.WriteAllText(LogPath + date.ToString("yyyy-MM-dd HH mm ss") + ".txt", sqlcmd);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                File.WriteAllText(LogPath + "INSERT___ERROR___" + date.ToString("yyyy-MM-dd HH mm ss") + ".txt", ex.ToString());
            }

        }


        static void getQuakeData()
        {
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;
            //string URL = @"https://opendata.cwb.gov.tw/api/v1/rest/datastore/E-A0015-001?Authorization=rdec-key-123-45678-011121314";
            using (WebClient wc = new WebClient())
            {
                try
                {
                    wc.Encoding = Encoding.UTF8; // 設定Webclient.Encoding
                    string jsonString = wc.DownloadString(ApiUrl);
                    //File.WriteAllText(LogPath + "json__" +date.ToString("yyyy-MM-dd HH mm ss") + ".txt", jsonString);
                    JObject json = JObject.Parse(jsonString);
                    var loopData = json["records"]["earthquake"];
                    int cnt = ((Newtonsoft.Json.Linq.JContainer)(loopData)).Count - 1;
                    for (int i = 0; i <= cnt; i++)
                    {
                        ToSqlData data = new ToSqlData();
                        data.earthquakeNo = loopData[i]["earthquakeNo"].ToString();
                        data.web = loopData[i]["web"].ToString();
                        data.reportImageURI = loopData[i]["reportImageURI"].ToString();
                        data.originTime = loopData[i]["earthquakeInfo"]["originTime"].ToString();
                        data.location = loopData[i]["earthquakeInfo"]["epiCenter"]["location"].ToString();
                        data.magnitudeValue = loopData[i]["earthquakeInfo"]["magnitude"]["magnitudeValue"].ToString();
                        data.GIS_DATETIME = date.ToString("yyyy/MM/dd HH:mm:ss");
                        listData.Add(data);
                    }

                }
                catch (Exception ex)
                {
                    File.WriteAllText(LogPath + "ERROR___" +date.ToString("yyyy-MM-dd HH mm ss") + ".txt", ex.ToString());
                }

            }

        }

        static void Main(string[] args)
        {
            // Create Log Dir.
            if (!System.IO.Directory.Exists(LogPath))
                System.IO.Directory.CreateDirectory(LogPath);

            getQuakeData();
            insertNewData();
        }
    }
}
