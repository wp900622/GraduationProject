package fcu.iecs.volunteer.model.payload;

import lombok.Data;

@Data
public class MateRequest {
    String schoolname;


    String volunteermail;



    String stuemail;


}
